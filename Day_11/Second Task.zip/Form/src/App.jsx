import SignUpForm from "./Components/SignUpForm";

function App(){
  return<>
      <SignUpForm/>
  </>
}
export default App;